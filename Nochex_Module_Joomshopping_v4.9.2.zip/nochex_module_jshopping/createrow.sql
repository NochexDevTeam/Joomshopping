INSERT INTO jos_jshopping_payment_method
(
`name_en-GB`, `name_de-DE`, `payment_code`, `payment_class`, `payment_publish`, `payment_ordering`, `payment_params`, `payment_type`, `price`, `tax_id`, `show_descr_in_email`
)
VALUES
(
'Nochex', 'Nochex', 'nochex', 'pm_nochex', 1, 7, 'testmode=0
email_received=
transaction_end_status=6
transaction_pending_status=1
transaction_failed_status=3
checkdatareturns=1', 2, 0.00, 1, 0
)