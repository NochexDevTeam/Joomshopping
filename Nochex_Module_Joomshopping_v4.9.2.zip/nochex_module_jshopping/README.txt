1) Run the .sql file in a program like phpmyadmin

2) Place the components/com_jshopping/pm_nochex folder along with 
the files int it, in the corresponding directory on your server

3) As for the components/com_jshopping_lang/en-GB.php.txt and 
administrator/components/com_jshopping/lang/en-GB.php.txt files 
open them up and follow the instructions and complete the instructions on the
corresponding files
