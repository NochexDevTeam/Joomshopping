<script type="text/javascript">
function check_pm_nochex(){
    $_('payment_form').submit();
}
</script>